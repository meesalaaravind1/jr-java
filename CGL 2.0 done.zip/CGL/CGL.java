import java.util.*;

public class CGL{
    Board board;
    int size;

    CGL(Cell [] liveCells , int sizeOfBoard){
        this.board = new Board(sizeOfBoard);
        this.size = sizeOfBoard;
        // ArrayList<Cell> al= new ArrayList<Cell>();
        // for (int i=0;i<liveCells.length;i++){
        //     al.add(liveCells[i]);
        // }
        for (int i =0;i<sizeOfBoard;i++){
            for (int j=0;j<sizeOfBoard;j++){
                // if (al.contains(board.cells[i][j])){
                //     board.cells[i][j]=new Cell(i,j,true);
                // }
                for (int k=0;k<liveCells.length;k++){
                    if (this.board.cells[i][j].equals(liveCells[k])){
                        this.board.cells[i][j]=new Cell(i,j,true);
                    }
                }
            }
        }
    }

    public Board getNextGeneration(){
        Cell [][] newBoard=new Cell [this.board.cells.length][this.board.cells.length];
        for (int i=0;i<this.size;i++){
            for (int j=0;j<this.size;j++){
                newBoard[i][j]= new Cell(i,j);
            }
        }
        for(int i=0;i<this.board.cells.length;i++){
            for (int j=0;j<this.board.cells.length;j++){
                int cnt=0;
                int sr=-1;
                int sc=-1;
                int er=1;
                int ec=1;
                if (i==0){
                    sr=0;}

                if (i==this.board.cells.length-1){
                    er=0;}

                if (j==0){
                    sc=0;}

                if (j==this.board.cells.length-1){
                    ec=0;}

                for(int i1=sr;i1<=er;i1++){
                    for (int j1=sc;j1<=ec;j1++){
                        if (this.board.cells[i+i1][j+j1].life==true && (i1!=0 || j1!=0)){
                            cnt+=1;}
                    }
                }

                if (this.board.cells[i][j].life==true){
                    if (cnt==2 || cnt==3){
                        newBoard[i][j]=new Cell(i,j,true);}
                }

                else{
                    if (cnt==3){
                        newBoard[i][j]=new Cell(i,j,true);}
                }
            }
        }
        this.board.cells=newBoard;
        // System.out.println(this.board.toString());
        return this.board;
    }

    public static void main(String [] args){

        Cell c1=new Cell(1,1);
        Cell c2=new Cell(1,2);
        Cell c3=new Cell(1,0);
        Cell c4=new Cell(0,1);
        Cell [] live = {c1,c2,c3,c4};
        CGL cgl= new CGL(live,5);
        System.out.println(cgl.board);
        cgl.getNextGeneration();
        System.out.println(cgl.board);
        cgl.getNextGeneration();
        System.out.println(cgl.board);
    }
}