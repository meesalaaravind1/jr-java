import java.util.*;

public class Cell{
    int row;
    int col;
    boolean life;

    Cell(int row,int col){
        this.row=row;
        this.col=col;
        this.life=false;
    }

    Cell(int row,int col,boolean b){
        this.row=row;
        this.col=col;
        this.life=b;
    }


    public boolean isAlive(){
        return this.life;
    }

    public void makeAlive(){
        this.life=true;
    }

    public void makeDead(){
        this.life=false;
    }

    public int getRow(){
        return this.row;
    }
    public int getCol(){
        return this.col;
    }
    public boolean getStatus(){
        return this.life;
    }

    public boolean equals(Cell that){
        if ((this.row==that.row) && (this.col==that.col)){
            return true;
        }
        return false;
    }

    public String toString(){
        return ""+this.row+","+this.col+","+this.life;
    }

    public static void main (String[] args){
        Cell c = new Cell(1,1);
        System.out.println(c);
        c.makeAlive();
        System.out.println(c);
        c.makeDead();
        System.out.println(c);
        System.out.println(c.getRow());
        System.out.println(c.getCol());
        System.out.println(c.getStatus());
        Cell c2= new Cell(1,1);
        System.out.println(c.equals(c2));

    }
}
